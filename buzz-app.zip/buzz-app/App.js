import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { Header } from 'react-native-elements';
import {createAppContainer} from 'react-navigation'; 
import {createBottomTabNavigator} from 'react-navigation-tabs'
import instaScreen from './screens/instaScreen'
import facebookScreen from './screens/facebookScreen'

export default class App extends React.Component {
  render() {
    return (
      <AppContainer/>
    )
  }
}

const tabNavigator = createBottomTabNavigator({
  Facebook: {screen: facebookScreen},
  Instagram: {screen: instaScreen}
})

const AppContainer = createAppContainer(tabNavigator)